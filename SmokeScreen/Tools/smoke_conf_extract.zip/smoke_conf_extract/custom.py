import pefile
import deobfuscation
from sys import argv


def fix_opaque(sample_data, sample_path):
    pe_rep = pefile.PE(data=sample_data)

    opaque_predicate_info = deobfuscation.get_opaque_predicate_offsets(sample_data, pe_rep)
    cleaned_pe = deobfuscation.replace_ops(sample_data, opaque_predicate_info)

    patched_filename = sample_path.split(".")[0] + "_no_opaque_predicates.bin"
    print("Writing results to : ", patched_filename)
    with open(patched_filename, "wb") as f:
        f.write(cleaned_pe)


if __name__ == "__main__":
     
    if len(argv) < 2:
            print("No target file!")
            exit()
        
    print("Loading : ", argv[1])
    with open(argv[1], 'rb') as f:
        data = bytearray(f.read())
    
    fix_opaque(data, argv[1])
    